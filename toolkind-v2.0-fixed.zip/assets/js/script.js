\
(function(){
  const html = document.documentElement;
  const themeBtn = document.getElementById('themeBtn');
  const menuBtn = document.getElementById('menuBtn');
  const drawer = document.getElementById('drawer');
  const closeDrawer = document.getElementById('closeDrawer');
  const overlay = document.getElementById('overlay');
  const y = document.getElementById('year');
  const langSelect = document.getElementById('langSelect');

  if(y) y.textContent = new Date().getFullYear();

  // Theme toggle
  const savedTheme = localStorage.getItem('tk_theme') || 'light';
  if(savedTheme === 'dark') html.classList.add('dark');
  themeBtn?.addEventListener('click', ()=>{
    html.classList.toggle('dark');
    localStorage.setItem('tk_theme', html.classList.contains('dark')?'dark':'light');
  });

  // Drawer
  function openDrawer(){ drawer?.classList.add('open'); overlay?.classList.add('show'); }
  function hideDrawer(){ drawer?.classList.remove('open'); overlay?.classList.remove('show'); }
  menuBtn?.addEventListener('click', openDrawer);
  closeDrawer?.addEventListener('click', hideDrawer);
  overlay?.addEventListener('click', hideDrawer);

  // i18n
  const dict = {
    ar: {
      nav_home:"الرئيسية", nav_tools:"الأدوات", nav_blog:"المدونة", nav_about:"من نحن", nav_donate:"تبرّع", nav_contact:"اتصل بنا", nav_privacy:"سياسة الخصوصية", nav_terms:"شروط الاستخدام",
      home_h1:"منصة أدوات غير ربحية لخدمة الجميع", home_p:"نقدّم أدوات مجانية سريعة وآمنة — بدون تتبع وبدون تعقيد.", home_cta:"ابدأ الآن",
      popular_h2:"الأدوات الشائعة", t_ic:"تحويل الصور", t_cmp:"ضغط الصور", t_qr:"مولد QR", t_split:"تقسيم ملفات", t_units:"محول الوحدات", t_url:"اختصار الروابط", t_json:"تنسيق JSON", t_css:"تصغير CSS", more_btn:"عرض المزيد",
      tools_h1:"الأدوات", ic_h3:"تحويل الصور (PNG ⇄ JPG)", btn_convert:"تحويل",
      cmp_h3:"ضغط الصور (JPG جودة)", cmp_quality:"الجودة:", btn_compress:"ضغط",
      qr_h3:"مولد QR (بسيط)", btn_generate:"توليد",
      url_h3:"اختصار الروابط (محلي)", btn_shorten:"اختصر",
      json_h3:"تنسيق JSON", btn_format:"تنسيق", btn_minify:"تصغير",
      css_h3:"تصغير CSS",
      units_h3:"محول الوحدات (طول)",
      split_h3:"تقسيم ملف نصي", split_chars:"عدد الأحرف لكل جزء:", btn_split:"تقسيم",
      about_h1:"من نحن", about_p:"ToolKind مبادرة غير ربحية تهدف لتوفير أدوات رقمية مجانية وسهلة للجميع.",
      donate_h1:"تبرّع", donate_p:"يساعدنا دعمك على الاستضافة والتطوير وبناء أدوات مجانية.", donate_pp:"PayPal", donate_bmc:"BuyMeACoffee", donate_pt:"Patreon",
      contact_h1:"اتصل بنا", contact_name:"الاسم", contact_email:"البريد الإلكتروني", contact_msg:"رسالتك", contact_send:"إرسال",
      privacy_h1:"سياسة الخصوصية", privacy_p1:"تعمل الأدوات محليًا على جهازك ولا نحتفظ بأي بيانات.",
      terms_h1:"شروط الاستخدام", terms_p1:"باستخدامك للموقع، فإنك توافق على استخدام الأدوات على مسؤوليتك وبدون أي ضمانات.",
      blog_h1:"المدونة", blog_post1_h:"إطلاق ToolKind v2.0", blog_post1_p:"تصميم أزرق جديد، قائمة جانبية، وأدوات تعمل محليًا 100٪."
    },
    en: {
      nav_home:"Home", nav_tools:"Tools", nav_blog:"Blog", nav_about:"About", nav_donate:"Donate", nav_contact:"Contact", nav_privacy:"Privacy", nav_terms:"Terms",
      home_h1:"A Non‑Profit Toolkit for Everyone", home_p:"Free, fast, and privacy‑friendly tools — no tracking, no hassle.", home_cta:"Get Started",
      popular_h2:"Popular Tools", t_ic:"Image Convert", t_cmp:"Image Compress", t_qr:"QR Generator", t_split:"Split Files", t_units:"Unit Converter", t_url:"Shorten Links", t_json:"Format JSON", t_css:"Minify CSS", more_btn:"See more",
      tools_h1:"Tools", ic_h3:"Image Convert (PNG ⇄ JPG)", btn_convert:"Convert",
      cmp_h3:"Image Compress (JPG quality)", cmp_quality:"Quality:", btn_compress:"Compress",
      qr_h3:"QR Generator (simple)", btn_generate:"Generate",
      url_h3:"Link Shortener (local)", btn_shorten:"Shorten",
      json_h3:"JSON Formatter", btn_format:"Format", btn_minify:"Minify",
      css_h3:"Minify CSS",
      units_h3:"Unit Converter (Length)",
      split_h3:"Split Text File", split_chars:"Characters per part:", btn_split:"Split",
      about_h1:"About Us", about_p:"ToolKind is a non‑profit initiative providing easy, free digital tools for all.",
      donate_h1:"Support Us", donate_p:"Your support helps hosting, development, and more free tools.", donate_pp:"PayPal", donate_bmc:"BuyMeACoffee", donate_pt:"Patreon",
      contact_h1:"Contact Us", contact_name:"Name", contact_email:"Email", contact_msg:"Your message", contact_send:"Send",
      privacy_h1:"Privacy Policy", privacy_p1:"Most tools run locally on your device; we do not store your data.",
      terms_h1:"Terms of Use", terms_p1:"By using this site you agree to use the tools at your own risk without warranties.",
      blog_h1:"Blog", blog_post1_h:"ToolKind v2.0 Launch", blog_post1_p:"Fresh blue design, sidebar menu, and fully local tools."
    }
  };

  function applyI18n(lang){
    const map = dict[lang] || dict.ar;
    document.documentElement.lang = lang;
    document.documentElement.dir = (lang==='ar') ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach(el=>{
      const key = el.getAttribute('data-i18n');
      if(map[key]) el.textContent = map[key];
    });
  }

  const savedLang = localStorage.getItem('tk_lang') || 'ar';
  langSelect && (langSelect.value = savedLang);
  applyI18n(savedLang);
  langSelect?.addEventListener('change', (e)=>{
    const v = e.target.value;
    localStorage.setItem('tk_lang', v);
    applyI18n(v);
  });

  // Tools
  window.imageConvert = async function(){
    const f = document.getElementById('ic_file').files[0];
    const fmt = document.getElementById('ic_fmt').value;
    if(!f) return alert(savedLang==='ar'?'اختر صورة أولاً':'Pick an image first');
    const img = new Image();
    img.onload = ()=>{
      const c = document.createElement('canvas');
      c.width = img.width; c.height = img.height;
      c.getContext('2d').drawImage(img,0,0);
      const url = c.toDataURL(fmt);
      const a = document.getElementById('ic_download');
      a.href = url; a.download = 'converted' + (fmt==='image/png'?'.png':'.jpg');
      a.textContent = savedLang==='ar'?'تحميل الصورة (جاهز)':'Download (ready)';
    };
    img.src = URL.createObjectURL(f);
  };

  window.imageCompress = async function(){
    const f = document.getElementById('cmp_file').files[0];
    const q = parseFloat(document.getElementById('cmp_q').value || '0.7');
    if(!f) return alert(savedLang==='ar'?'اختر صورة أولاً':'Pick an image first');
    const img = new Image();
    img.onload = ()=>{
      const c = document.createElement('canvas');
      c.width = img.width; c.height = img.height;
      c.getContext('2d').drawImage(img,0,0);
      const url = c.toDataURL('image/jpeg', q);
      const a = document.getElementById('cmp_download');
      a.href = url; a.textContent = savedLang==='ar'?'تحميل الصورة المضغوطة':'Download compressed';
    };
    img.src = URL.createObjectURL(f);
  };

  window.qrGenerate = function(){
    const t = document.getElementById('qr_text').value || 'ToolKind';
    const c = document.getElementById('qr_canvas');
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0,0,c.width,c.height);
    ctx.fillStyle = '#111827';
    let h = 0; for(let i=0;i<t.length;i++){ h = (h*31 + t.charCodeAt(i)) & 0xffffffff; }
    const size = 16;
    for(let y=0;y<16;y++){
      for(let x=0;x<16;x++){
        const bit = (h >> ((x+y)%32)) & 1;
        if(bit){ ctx.fillRect(x*size+4, y*size+4, size-3, size-3); }
      }
    }
  };

  window.shortenUrl = function(){
    const i = document.getElementById('url_input').value.trim();
    if(!i) return;
    let h = 0; for(let k=0;k<i.length;k++){ h = (h*33 + i.charCodeAt(k)) & 0xffffffff; }
    const code = Math.abs(h).toString(36).slice(0,6);
    document.getElementById('url_output').value = location.origin + '/u/' + code;
  };

  window.jsonFormat = function(){
    try{
      const v = JSON.parse(document.getElementById('json_in').value);
      document.getElementById('json_out').value = JSON.stringify(v,null,2);
    }catch(e){ alert(savedLang==='ar'?'JSON غير صالح':'Invalid JSON'); }
  };
  window.jsonMinify = function(){
    try{
      const v = JSON.parse(document.getElementById('json_in').value);
      document.getElementById('json_out').value = JSON.stringify(v);
    }catch(e){ alert(savedLang==='ar'?'JSON غير صالح':'Invalid JSON'); }
  };

  window.cssMinify = function(){
    const s = document.getElementById('css_in').value;
    const out = s.replace(/\/\*[\s\S]*?\*\//g,'').replace(/\s+/g,' ').replace(/\s*([{};:,])\s*/g,'$1').trim();
    document.getElementById('css_out').value = out;
  };

  function toMeters(val, unit){
    if(unit==='m') return val;
    if(unit==='km') return val*1000;
    if(unit==='cm') return val/100;
    return val;
  }
  function fromMeters(val, unit){
    if(unit==='m') return val;
    if(unit==='km') return val/1000;
    if(unit==='cm') return val*100;
    return val;
  }
  window.unitConvert = function(){
    const v = parseFloat(document.getElementById('u_val').value||'0');
    const f = document.getElementById('u_from').value;
    const t = document.getElementById('u_to').value;
    const m = toMeters(v,f);
    document.getElementById('u_out').value = fromMeters(m,t);
  };

  window.splitFile = async function(){
    const f = document.getElementById('sp_file').files[0];
    const size = parseInt(document.getElementById('sp_size').value||'500',10);
    if(!f) return alert(savedLang==='ar'?'ارفع ملف .txt أولاً':'Upload a .txt file first');
    const text = await f.text();
    const links = document.getElementById('sp_links');
    links.innerHTML='';
    for(let i=0;i<text.length;i+=size){
      const chunk = text.slice(i,i+size);
      const blob = new Blob([chunk], {type:'text/plain'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `part_${(i/size)+1}.txt`; a.textContent = (savedLang==='ar'?'تنزيل الجزء ':'Download part ')+((i/size)+1);
      const div = document.createElement('div'); div.appendChild(a);
      links.appendChild(div);
    }
  };

  window.contactSend = function(e){
    e.preventDefault();
    alert(savedLang==='ar'?'تم الإرسال بنجاح 👍':'Sent successfully 👍');
  };
})();