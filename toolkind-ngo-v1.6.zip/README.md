# ToolKind NGO — v1.6

نسخة نظيفة وخفيفة متعددة الصفحات (AR/EN) مع تبديل الثيم، جاهزة للنشر على GitHub Pages أو Vercel.

## البنية
- index.html, about.html, tools.html, donate.html, contact.html, privacy.html, terms.html, blog.html
- assets/css/style.css
- assets/js/script.js
- assets/img/favicon.png

## النشر السريع (Vercel)
1) vercel init ثم vercel deploy
2) أو اربط الريبو من GitHub واضغط Deploy

## النشر (GitHub Pages)
- ضع الملفات في الفرع `main`
- من Settings > Pages اختر المصدر من `root`
