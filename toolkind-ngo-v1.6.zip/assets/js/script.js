\
(function(){
  // Theme
  const html = document.documentElement;
  const savedTheme = localStorage.getItem('theme') || 'dark';
  if(savedTheme === 'light'){ html.classList.add('light'); }
  const themeToggle = document.getElementById('themeToggle');
  if(themeToggle){
    themeToggle.addEventListener('click', ()=>{
      html.classList.toggle('light');
      localStorage.setItem('theme', html.classList.contains('light') ? 'light':'dark');
    });
  }

  // Year
  const y = document.getElementById('year');
  if(y) y.textContent = new Date().getFullYear();

  // i18n
  const dict = {
    ar: {
      nav_home:"الرئيسية", nav_about:"من نحن", nav_tools:"الأدوات", nav_blog:"المدونة", nav_donate:"تبرّع", nav_contact:"اتصل بنا",
      footer_about_h:"عن ToolKind", footer_about_p:"منصة غير ربحية تقدّم أدوات رقمية مجانية تخدم المجتمع.",
      footer_links_h:"روابط", footer_privacy:"سياسة الخصوصية", footer_terms:"شروط الاستخدام",
      footer_news_h:"النشرة البريدية", footer_subscribe:"اشترك",
      home_h1:"منصة أدوات غير ربحية لخدمة المجتمع",
      home_p:"نجمع أدوات بسيطة ومفيدة وسريعة — بدون تتبع وبدون إعلانات مزعجة.",
      home_cta_tools:"استعرض الأدوات", home_cta_donate:"ادعمنا",
      f1_h:"مجانية بالكامل", f1_p:"كل الأدوات متاحة للجميع بدون مقابل.",
      f2_h:"سريعة وآمنة", f2_p:"تصميم خفيف وتحميل فائق السرعة.",
      f3_h:"مفتوحة للمجتمع", f3_p:"نستمع لمقترحاتكم ونطوّر باستمرار.",
      about_h1:"من نحن", about_p1:"ToolKind مبادرة غير ربحية تهدف لتوفير أدوات رقمية مجانية تخدم التعليم والمجتمع.",
      mission_h:"المهمة", mission_p:"تمكين الجميع من الوصول إلى أدوات رقمية سهلة وآمنة.",
      vision_h:"الرؤية", vision_p:"أن تصبح الأدوات المجانية معياراً للجودة والموثوقية.",
      tools_h1:"مكتبة الأدوات", tools_p:"تجد هنا أدوات بسيطة تعمل محليًا في المتصفح دون رفع بياناتك.",
      tool_qr_h:"مولّد QR", tool_qr_p:"حوّل النصوص والروابط إلى رمز QR.",
      tool_links_h:"أقصر الروابط", tool_links_p:"تنسيق ومشاركة الروابط بسهولة.",
      tool_pdf_h:"دمج PDF", tool_pdf_p:"ادمج ملفات PDF محلياً.",
      qr_h2:"مولّد QR", qr_btn:"إنشاء",
      donate_h1:"ادعمنا", donate_p:"تبرعك يساعدنا على الاستضافة، التطوير، وبناء أدوات مجانية للجميع.", donate_pp:"PayPal", donate_bmc:"BuyMeACoffee", donate_pt:"Patreon",
      contact_h1:"اتصل بنا", contact_name:"الاسم", contact_email:"البريد الإلكتروني", contact_msg:"رسالتك", contact_send:"إرسال",
      privacy_h1:"سياسة الخصوصية", privacy_p1:"نحترم خصوصيتك. تعمل معظم الأدوات محليًا على جهازك ولا نحتفظ بأي بيانات.",
      terms_h1:"شروط الاستخدام", terms_p1:"باستخدامك للموقع، فإنك توافق على استخدام الأدوات على مسؤوليتك وبدون أي ضمانات.",
      blog_h1:"المدونة"
    },
    en: {
      nav_home:"Home", nav_about:"About", nav_tools:"Tools", nav_blog:"Blog", nav_donate:"Donate", nav_contact:"Contact",
      footer_about_h:"About ToolKind", footer_about_p:"A non-profit platform offering free, community-serving digital tools.",
      footer_links_h:"Links", footer_privacy:"Privacy Policy", footer_terms:"Terms of Use",
      footer_news_h:"Newsletter", footer_subscribe:"Subscribe",
      home_h1:"A Non‑Profit Toolkit for the Community",
      home_p:"Simple, useful, fast tools — no tracking and no intrusive ads.",
      home_cta_tools:"Explore Tools", home_cta_donate:"Support Us",
      f1_h:"Completely Free", f1_p:"All tools are available to everyone at no cost.",
      f2_h:"Fast & Secure", f2_p:"Lightweight design and blazing fast load.",
      f3_h:"Community‑Driven", f3_p:"We listen to your feedback and improve continuously.",
      about_h1:"About Us", about_p1:"ToolKind is a non-profit initiative providing free digital tools for education and society.",
      mission_h:"Mission", mission_p:"Enable everyone to access easy and safe digital tools.",
      vision_h:"Vision", vision_p:"Make free tools a standard for quality and reliability.",
      tools_h1:"Tools Library", tools_p:"Tools run locally in your browser — no uploads needed.",
      tool_qr_h:"QR Generator", tool_qr_p:"Turn text and links into QR codes.",
      tool_links_h:"Shorten Links", tool_links_p:"Format and share links with ease.",
      tool_pdf_h:"Merge PDF", tool_pdf_p:"Merge PDFs locally.",
      qr_h2:"QR Generator", qr_btn:"Generate",
      donate_h1:"Support Us", donate_p:"Your donation funds hosting, development, and free tools for all.", donate_pp:"PayPal", donate_bmc:"BuyMeACoffee", donate_pt:"Patreon",
      contact_h1:"Contact Us", contact_name:"Name", contact_email:"Email", contact_msg:"Your message", contact_send:"Send",
      privacy_h1:"Privacy Policy", privacy_p1:"Most tools run locally on your device; we do not store your data.",
      terms_h1:"Terms of Use", terms_p1:"By using this website you agree to use the tools at your own risk and with no warranties.",
      blog_h1:"Blog"
    }
  };

  function applyI18n(lang){
    const map = dict[lang] || dict.ar;
    document.documentElement.lang = lang;
    document.documentElement.dir = (lang === 'ar') ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach(el=>{
      const key = el.getAttribute('data-i18n');
      if(map[key]) el.textContent = map[key];
    });
  }

  const langSelect = document.getElementById('langSelect');
  const savedLang = localStorage.getItem('lang') || 'ar';
  if(langSelect){
    langSelect.value = savedLang;
    applyI18n(savedLang);
    langSelect.addEventListener('change', (e)=>{
      const v = e.target.value;
      localStorage.setItem('lang', v);
      applyI18n(v);
    });
  } else {
    applyI18n(savedLang);
  }

  // Fake subscribe
  window.subscribe = function(e){
    e.preventDefault();
    alert((document.documentElement.lang==='ar')?'تم الاشتراك بنجاح!':'Subscribed successfully!');
  }

  // Contact
  window.sendContact = function(e){
    e.preventDefault();
    alert((document.documentElement.lang==='ar')?'تم إرسال رسالتك!':'Your message has been sent!');
  }

  // Simple QR (no external libs): draw text as QR placeholder (not real QR)
  window.genQR = function(){
    const c = document.getElementById('qrCanvas');
    if(!c) return;
    const ctx = c.getContext('2d');
    ctx.fillStyle = (getComputedStyle(document.documentElement).getPropertyValue('--card')||'#fff').trim();
    ctx.fillRect(0,0,c.width,c.height);
    ctx.fillStyle = '#000';
    // Simple placeholder pattern based on string hash
    const t = document.getElementById('qrText').value || 'ToolKind';
    let h = 0; for(let i=0;i<t.length;i++){ h = (h*31 + t.charCodeAt(i)) & 0xffffffff; }
    const size = 16;
    for(let y=0;y<16;y++){
      for(let x=0;x<16;x++){
        const bit = (h >> ((x+y)%32)) & 1;
        if(bit){
          ctx.fillRect(x*size+4, y*size+4, size-3, size-3);
        }
      }
    }
  }
})(); 
